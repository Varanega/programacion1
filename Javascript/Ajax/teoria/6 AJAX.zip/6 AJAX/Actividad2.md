Crea un chat sencillo
