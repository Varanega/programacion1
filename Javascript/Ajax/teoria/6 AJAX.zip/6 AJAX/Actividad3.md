Crea un buscador de payasos. Los resultados se mostrarán en un paginador de 4 líneas (4 resultados).

El campo de busqueda contendrá un campo de texto y un botón con el texto "Buscar".

La base de datos contendrá una tabla con el nombre "payasos". Dentro tendrá dos columnas: id y nombre. Rellena con 10 resultados como mínimo.

Si careces de imaginación o tu cerebro se niega a trabajar, dejo a continuación una lista de posibles nombres.

-Cepillín
-The jocker
-Krusty
-El payaso de IT 
-Ronald McDonald
-El Guasón
-Gaby, Fofó y Miliki
-Bozo el payaso
-Pagliacci Luciano Pavarotti
