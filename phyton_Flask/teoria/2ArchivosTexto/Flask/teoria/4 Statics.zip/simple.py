# -*- coding: utf-8 -*-
from flask import Flask, url_for
app = Flask(__name__)

@app.route("/")
def index():
    ruta = url_for('static', filename='desierto.jpg')
    return '''
        <img src="{0}">
    '''.format(ruta)

if __name__ == "__main__":
    app.run(debug=True)
